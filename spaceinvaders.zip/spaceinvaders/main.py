""" Space Invaders by @wyvvo

    Original project from github.com/attreyabhatt/space-invaders-pygame/

    Simple version.
    This is an emulation of original game Space Invaders.
    If the aliens reache the bottom of the screen,
    the game is over.
    The Player win if kills 50 aliens. 
     Further versions i may introduce some levels more difficults. 
"""


import pygame
import random
import math
import os
from pygame import mixer

# Initialize the pygame
pygame.init()

# create the screen
screen = pygame.display.set_mode((800, 600))

# Background
background = pygame.image.load("bg.png")
mixer.music.load("background.wav")
mixer.music.play(-1)


# Title and icon
pygame.display.set_caption("Space Invaders")
icon = pygame.image.load("space-invaders.png")
pygame.display.set_icon(icon)

# Score
score_value = 0
font = pygame.font.Font("freesansbold.ttf", 32)
textX = 10
textY = 10


# Player
playerImg = pygame.image.load("spaceship.png")
playerX = 370
playerY = 480
playerX_change = 0

# Enemy
enemyImg = []
enemyX = []
enemyY = []
enemyX_change = []
enemyY_change = []
inc_enemy_dx = []  # increment the x velocity
num_of_enemies = 6

# Put the aliens randomly - Initial state
for e in range(num_of_enemies):
    enemyImg.append(pygame.image.load("alien.png"))
    enemyX.append(random.randint(0,735))
    enemyY.append(random.randint(50, 150))
    enemyX_change.append(3)
    enemyY_change.append(40)

# Missile
# Ready - You can't see the bullet on the screen
# Fire - The missile is currently moving
missileImg = pygame.image.load("missile.png")
missileX = random.randint(0,800)
missileY = 480
missileX_change = 0
missileY_change = 10
missile_state = "ready"
ammo = 80          # total number of missiles available. 

# Game Over text
over_font = pygame.font.Font("freesansbold.ttf", 90)

# Victory font
win_font = pygame.font.Font("freesansbold.ttf", 90)

# Mission font
miss_font = pygame.font.Font("freesansbold.ttf", 90)

# Description font
desc_font = pygame.font.Font("freesansbold.ttf", 24)




# Kill enemy
"""
def pop_enemies(i):
    enemyImg.pop(i)
    enemyX.pop(i)
    enemyY.pop(i)
    enemyX_change.pop(i)
    enemyY_change.pop(i)

def append_enemies():
    enemyImg.append(pygame.image.load("alien.png"))
    enemyX.append(random.randint(0,735))
    enemyY.append(random.randint(50, 150))
    enemyX_change.append(3)
    enemyY_change.append(40)
"""

def game_over_text():
    over_text = font.render("GAME OVER", True, (255, 255, 255))
    screen.blit(over_text, (300, 300))

def win_text():
    win_text = font.render("MISSION ACCOMPLISHED", True, (255, 255, 255))
    screen.blit(win_text, (300, 300))

def desc_text():
    desc_text = font.render("Kill 50 aliens", True, (255, 255, 255))
    screen.blit(desc_text, (300, 10))

def show_score(x,y):
    score = font.render("Score :" + str(score_value), True, (255,255,255))
    missiles = font.render("Ammo :" + str(ammo), True, (255,255,255))
    screen.blit(score, (x, y))
    screen.blit(missiles, (x + 600, y))

def fire_missile(x, y):
    global missile_state, ammo 
    missile_state = "fire"
    screen.blit(missileImg, (x +16, y+10))


def player(x, y):
    screen.blit(playerImg, (x, y))


def enemy(x, y, i):
    screen.blit(enemyImg[i], (x, y))

# Coordinates of enemy (eX, eY), coordinates of missile (mX, mY)
def isCollision(eX, eY, mX, mY):
    distance = math.sqrt(math.pow(eX-mX,2) + math.pow(eY - mY,2))
    if distance < 27:
        return True
    else:
        return False


# Game Loop
running = True

while running :
    
    
    # RGB - Red, Green , Blu
    screen.fill((0, 0, 0))
    # bg image
    screen.blit(background, (0,0))

    desc_text()
    
    # listen the events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    
        # if keystroke is pressed check whether its right o left
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                playerX_change = -10
            if event.key == pygame.K_RIGHT:
                playerX_change = 10
            if event.key == pygame.K_SPACE:
                if missile_state is "ready":
                    missile_sound = mixer.Sound("laser.wav")
                    missile_sound.play()
                    missileX = playerX
                    fire_missile(missileX, missileY)
                    ammo -= 1
                    #os.system("aplay laser.wav&")

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                playerX_change = 0

    # Cehcking for boundaries of spaceships
    playerX += playerX_change

    if playerX <= 0:
        playerX = 0
    elif playerX > 736:
        playerX = 736

    # Enemy movement
    for i in range(num_of_enemies):

        # Game Over
        if enemyY[i] > 400:
            for j in range(num_of_enemies):
                enemyY[i] = 2000
            game_over_text()
            break
        
        if score_value >= 50 :
            win_text()
            break

        enemyX[i] += enemyX_change[i]


        # Check boundaries of aliens inverts the velocity x
        if enemyX[i] <= 0:
            enemyX_change[i] = 3
            enemyY[i] += enemyY_change[i] 
        elif enemyX[i] > 736:
            enemyX_change[i] = -3
            enemyY[i] += enemyY_change[i]
        
        # Collision
        collision = isCollision(enemyX[i], enemyY[i], missileX, missileY)
        if collision:
            explosion_sound = mixer.Sound("explosion.wav")
            explosion_sound.play()

            missileY = 480
            missile_state = "ready"
            score_value += 1
            # Respoon
            enemyX[i] = random.randint(0,735)
            enemyY[i] = random.randint(50, 150)

            # Kill the enemy - put over the screen and pop from the list
            # enemyX[i] = 2000
            # enemyY[i] = 2000
            # pop_enemies(i)

        enemy(enemyX[i], enemyY[i], i)

    
    # Missile movement
    if missileY <= 0 :
        missileY = 480
        missile_state = "ready"

    if missile_state is "fire":
        fire_missile(missileX, missileY)
        missileY -= missileY_change
    
    
    player(playerX, playerY)
    show_score(textX, textY)
    pygame.display.update()